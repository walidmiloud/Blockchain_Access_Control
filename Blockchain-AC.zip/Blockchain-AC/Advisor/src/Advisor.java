
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;

public class Advisor extends javax.swing.JFrame {

    static List<String> list_Subjects = new ArrayList<String>();
    static List<String> list_Objects = new ArrayList<String>();
    //static List<String> list_Sub_BC = new ArrayList<String>();
    //static List<String> list_Obj_BC = new ArrayList<String>();
    //static List<String> list_Task_BC = new ArrayList<String>();
    static List<Subject_inf> list_sub = new ArrayList<Subject_inf>();
    static List<Object_inf> list_obj = new ArrayList<Object_inf>();
    static List<String> list_Tas = new ArrayList<String>();

    static List<Block_Sub> Blockchain_Subject = new ArrayList<Block_Sub>();
    static List<Block_Ob> Blockchain_Object = new ArrayList<Block_Ob>();
    static List<Block_Task> Blockchain_Task = new ArrayList<Block_Task>();
    static List<Block_Threshold> Blockchain_Threshold = new ArrayList<Block_Threshold>();
    static List<Block_Smart_Contract> Blockchain_Smart_c = new ArrayList<Block_Smart_Contract>();

    static String type_request;
    static String Sub_id;
    static String Ob_id;
    static String Sub_position;
    static String Sub_value;
    static String Sub_date;
    static boolean get_domin_BC;
    static BigInteger public_k_e, private_k_d, public_k_n;
    static String HASH_DATA, PROOF_WORK;
    static int MinerPort = 4440;

    public Advisor() {
        initComponents();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        show = new javax.swing.JTextArea();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        id_ta = new javax.swing.JTextField();
        value_ta = new javax.swing.JTextField();
        date_ta = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        desc_ta = new javax.swing.JTextArea();
        jButton2 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        date_sc = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        rule_sc = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        id_sc = new javax.swing.JComboBox<>();
        jPanel6 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        value_th = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        date_th = new javax.swing.JTextField();
        id_object_th = new javax.swing.JComboBox<>();
        id_task_th = new javax.swing.JComboBox<>();
        jPanel7 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        value_ob = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        date_ob = new javax.swing.JTextField();
        id_object = new javax.swing.JComboBox<>();
        id_subject_ob = new javax.swing.JComboBox<>();
        jPanel8 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        posiotion_sub = new javax.swing.JTextField();
        value_sub = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        date_sub = new javax.swing.JTextField();
        id_subject = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jButton1.setText("Start Listen");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Output :");

        show.setColumns(20);
        show.setRows(5);
        jScrollPane2.setViewportView(show);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jButton1))
                        .addGap(0, 816, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 224, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Output", jPanel1);
        jPanel1.getAccessibleContext().setAccessibleName("");

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Task");

        jLabel6.setText("ID Task :");

        jLabel7.setText("Value :");

        jLabel8.setText("Date");

        jLabel9.setText("Description :");

        desc_ta.setColumns(20);
        desc_ta.setRows(5);
        jScrollPane1.setViewportView(desc_ta);

        jButton2.setText("Add");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(jLabel6)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(value_ta, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 85, Short.MAX_VALUE)
                            .addComponent(date_ta, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(id_ta)))
                    .addComponent(jLabel9)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jButton2)
                        .addGap(25, 25, 25))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(56, 56, 56))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addGap(27, 27, 27)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(id_ta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(value_ta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(date_ta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("Smart Contract");

        jLabel15.setText("ID Smart-C :");

        jLabel17.setText("Date :");

        jButton4.setText("Add");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        rule_sc.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153)));

        jLabel4.setText("Rule :");

        id_sc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Authorisation_Policy", "Priority_Policy" }));
        id_sc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                id_scActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5)
                            .addComponent(jButton4))
                        .addGap(9, 9, 9))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addComponent(jLabel15)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addGap(36, 36, 36)))
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(rule_sc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                                        .addComponent(id_sc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel17)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(date_sc)))))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(id_sc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(rule_sc, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(date_sc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19)
                .addComponent(jButton4)
                .addContainerGap())
        );

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel10.setText("Threshold");

        jLabel11.setText("ID Task :");

        jLabel12.setText("ID Object :");

        jLabel13.setText("Value :");

        jLabel14.setText("Date :");

        jButton3.setText("Add");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addComponent(jLabel11))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(id_object_th, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(id_task_th, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addGap(25, 25, 25)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(date_th, javax.swing.GroupLayout.DEFAULT_SIZE, 79, Short.MAX_VALUE)
                            .addComponent(value_th))))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addGap(0, 56, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addComponent(jButton3)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(22, 22, 22))))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addGap(27, 27, 27)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(id_task_th, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(id_object_th, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel13))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(value_th, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(date_th, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton3)
                .addContainerGap())
        );

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel18.setText("Object");

        jLabel19.setText("ID Object :");

        jLabel20.setText("ID Subject");

        jLabel21.setText("Value :");

        jLabel22.setText("Date :");

        jButton5.setText("Add");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel22)
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel7Layout.createSequentialGroup()
                            .addComponent(jLabel21)
                            .addGap(25, 25, 25)
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(date_ob)
                                .addComponent(value_ob)))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel7Layout.createSequentialGroup()
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel20)
                                .addComponent(jLabel19))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
                                .addComponent(id_object, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(id_subject_ob, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton5)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel18)
                .addGap(27, 27, 27)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(id_object, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(id_subject_ob, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel21))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(value_ob, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(date_ob, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 82, Short.MAX_VALUE)
                .addComponent(jButton5)
                .addContainerGap())
        );

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel23.setText("Subject");

        jLabel24.setText("ID Subject :");

        jLabel25.setText("Position :");

        jLabel26.setText("Value :");

        jLabel27.setText("Date :");

        jButton6.setText("Add");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel27)
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel8Layout.createSequentialGroup()
                            .addComponent(jLabel26)
                            .addGap(25, 25, 25)
                            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(date_sub)
                                .addComponent(value_sub)))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel8Layout.createSequentialGroup()
                            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel25)
                                .addComponent(jLabel24))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
                                .addComponent(id_subject, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(posiotion_sub)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton6)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel23)
                .addGap(27, 27, 27)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(id_subject, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(posiotion_sub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel26))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(value_sub, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(date_sub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton6)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Input", jPanel2);
        jPanel2.getAccessibleContext().setAccessibleName("");

        jLabel1.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        jLabel1.setText("Advisor");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(549, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(339, 339, 339))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 954, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        show.append("Advisor is started......\n");
        new show_info().start();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        ServerThread se = new ServerThread(null);
        try {
            type_request = "Ta_request";
            se.New_Block();
        } catch (IOException ex) {
            Logger.getLogger(Advisor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Advisor.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        ServerThread se = new ServerThread(null);
        try {
            type_request = "Sub_request";
            se.New_Block();
        } catch (IOException ex) {
            Logger.getLogger(Advisor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Advisor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

        ServerThread se = new ServerThread(null);
        try {
            type_request = "Ob_request";
            se.New_Block();
        } catch (IOException ex) {
            Logger.getLogger(Advisor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Advisor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        ServerThread se = new ServerThread(null);
        try {
            type_request = "Thr_request";
            se.New_Block();
        } catch (IOException ex) {
            Logger.getLogger(Advisor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Advisor.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        ServerThread se = new ServerThread(null);
        try {
            type_request = "SC_request";
            se.New_Block();
        } catch (IOException ex) {
            Logger.getLogger(Advisor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Advisor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void id_scActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_id_scActionPerformed
        if (id_sc.getSelectedIndex() == 0) {
            rule_sc.setText("<html>IF ( A >= Threshold )<br/> Ruturn: True <br/> <br/> ELSE <br/> Return: False</html>");
        }

        if (id_sc.getSelectedIndex() == 1) {
            rule_sc.setText("<html>IF ( A1 > A2 )<br/> Ruturn: A1 <br/> <br/> ELSE <br/>  Ruturn: A2 </html>");
        }

    }//GEN-LAST:event_id_scActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */

        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Advisor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField date_ob;
    private javax.swing.JTextField date_sc;
    private javax.swing.JTextField date_sub;
    private javax.swing.JTextField date_ta;
    private javax.swing.JTextField date_th;
    private javax.swing.JTextArea desc_ta;
    private javax.swing.JComboBox<String> id_object;
    private javax.swing.JComboBox<String> id_object_th;
    private javax.swing.JComboBox<String> id_sc;
    private javax.swing.JComboBox<String> id_subject;
    private javax.swing.JComboBox<String> id_subject_ob;
    private javax.swing.JTextField id_ta;
    private javax.swing.JComboBox<String> id_task_th;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField posiotion_sub;
    private javax.swing.JLabel rule_sc;
    private javax.swing.JTextArea show;
    private javax.swing.JTextField value_ob;
    private javax.swing.JTextField value_sub;
    private javax.swing.JTextField value_ta;
    private javax.swing.JTextField value_th;
    // End of variables declaration//GEN-END:variables

    public class show_info extends Thread {

        public void run() {
            Socket s = null;
            ServerSocket ss2 = null;

            try {
                ss2 = new ServerSocket(5000); // can also use static final PORT_NUM , when defined

            } catch (IOException e) {
                e.printStackTrace();
                show.append("Server error\n");

            }

            while (true) {
                try {
                    // start the function of the server
                    s = ss2.accept();
                    // show.append("connection Established");

                    ServerThread st = new ServerThread(s);
                    st.start();

                } catch (Exception e) {
                    e.printStackTrace();
                    show.append("Connection Error\n");

                }
            }

        }
    }

    class ServerThread extends Thread {

        String line = null;
        BufferedReader is = null;
        PrintWriter os = null;
        Socket s = null;
        boolean exist_D = false;

        public ServerThread(Socket s) {
            this.s = s;
        }

        public void run() {
            try {
                is = new BufferedReader(new InputStreamReader(s.getInputStream()));
                os = new PrintWriter(s.getOutputStream());

            } catch (IOException e) {
                show.append("IO error in server thread\n");
            }

            try {
                line = is.readLine();

                if (line.compareTo("Sub_request") == 0) {
                    type_request = "Sub_request";
                    // record its address and give it the dominant BC
                    //New_Block();

                    list_Subjects.add(is.readLine());
                    // put the list of subject in the combobox
                    DefaultComboBoxModel model = (DefaultComboBoxModel) id_subject.getModel();
                    model.addElement(list_Subjects.get(list_Subjects.size() - 1));

                    model = (DefaultComboBoxModel) id_subject_ob.getModel();
                    model.addElement(list_Subjects.get(list_Subjects.size() - 1));

                    send_BCs();

                } else if (line.compareTo("Ob_request") == 0) {
                    type_request = "Ob_request";
                    // record its address and give it the dominant BC
                    //New_Block();
                    list_Objects.add(is.readLine());
                    // put the list of object in the combobox
                    DefaultComboBoxModel model = (DefaultComboBoxModel) id_object.getModel();
                    model.addElement(list_Objects.get(list_Objects.size() - 1));

                    model = (DefaultComboBoxModel) id_object_th.getModel();
                    model.addElement(list_Objects.get(list_Objects.size() - 1));
                } else if (line.compareTo("get_subjects_addr") == 0) {
                    // send all the address of the subjects
                    send_subjects_address();
                }

                /*else if (line.compareTo("Delete_Subject") == 0) {
                    String m = is.readLine().toString();
                    list_Subjects.remove(m);
                    show.append("The Subject which is referenced by: " + m + " is Deleted\n");
                }
                 */
            } catch (IOException e) {

                line = this.getName(); //reused String line for getting thread name
                show.append("IO Error/ Client " + line + " terminated abruptly\n");
            } catch (NullPointerException e) {
                line = this.getName(); //reused String line for getting thread name
                show.append("Client " + line + " Closed\n");
            } finally {
                try {
                    //show.append("Connection Closing..");
                    if (is != null) {
                        is.close();
                        //show.append(" Socket Input Stream Closed");
                    }

                    if (os != null) {
                        os.close();
                        //show.append("Socket Out Closed");
                    }
                    if (s != null) {
                        s.close();
                        //show.append("Socket Closed");
                    }

                } catch (IOException ie) {
                    show.append("Socket Close Error\n");
                }
            }
        }

        // send all the address of the subjects
        void send_subjects_address() {
            //send the size of the list
            os.println(list_Subjects.size());
            os.flush();
            //send all the address of subjects
            for (int i = 0; i < list_Subjects.size(); i++) {
                os.println(list_Subjects.get(i));
                os.flush();
            }
        }

        /*
        // send all the subjects recorded in the BC
        void send_subjects_address_BC() {
            //send the size of the list
            os.println(list_Sub_BC.size());
            os.flush();
            //send all the address of subjects
            for (int i = 0; i < list_Sub_BC.size(); i++) {
                os.println(list_Sub_BC.get(i));
                os.flush();
            }
        }

         */
 /*    
        // send all the objects recorded in the BC
        void send_objects_address_BC() {
            //send the size of the list
            os.println(list_Obj_BC.size());
            os.flush();
            //send all the address of subjects
            for (int i = 0; i < list_Obj_BC.size(); i++) {
                os.println(list_Obj_BC.get(i));
                os.flush();
            }
        }
         */
 /*
        // send all the tasks recorded in the BC
        void send_tasks_address_BC() {
            //send the size of the list
            os.println(list_Task_BC.size());
            os.flush();
            //send all the address of subjects
            for (int i = 0; i < list_Task_BC.size(); i++) {
                os.println(list_Task_BC.get(i));
                os.flush();
            }
        }
         */
        // Send the Blockchains to the new Subject
        void send_BCs() {

            // Send BCs to New Subject
            //sub-BC
            os.println(Blockchain_Subject.size());
            os.flush();

            for (int k = 0; k < Blockchain_Subject.size(); k++) {
                os.println(Blockchain_Subject.get(k).Pro_Hash);
                os.flush();
                os.println(Blockchain_Subject.get(k).id);
                os.flush();
                os.println(Blockchain_Subject.get(k).position);
                os.flush();
                os.println(Blockchain_Subject.get(k).value);
                os.flush();
                os.println(Blockchain_Subject.get(k).date);
                os.flush();
                os.println(Blockchain_Subject.get(k).Hash);
                os.flush();
                os.println(Blockchain_Subject.get(k).Proof_w);
                os.flush();
                os.println(Blockchain_Subject.get(k).public_k_e.toString());
                os.flush();
                os.println(Blockchain_Subject.get(k).public_k_n.toString());
                os.flush();
                os.println(Blockchain_Subject.get(k).signature);
                os.flush();
            }

            //Ob-BC
            os.println(Blockchain_Object.size());
            os.flush();

            for (int k = 0; k < Blockchain_Object.size(); k++) {
                os.println(Blockchain_Object.get(k).Pro_Hash);
                os.flush();
                os.println(Blockchain_Object.get(k).id);
                os.flush();
                os.println(Blockchain_Object.get(k).id_s);
                os.flush();
                os.println(Blockchain_Object.get(k).value);
                os.flush();
                os.println(Blockchain_Object.get(k).date);
                os.flush();
                os.println(Blockchain_Object.get(k).Hash);
                os.flush();
                os.println(Blockchain_Object.get(k).Proof_w);
                os.flush();
                os.println(Blockchain_Object.get(k).public_k_e.toString());
                os.flush();
                os.println(Blockchain_Object.get(k).public_k_n.toString());
                os.flush();
                os.println(Blockchain_Object.get(k).signature);
                os.flush();
            }

            //Task-BC
            os.println(Blockchain_Task.size());
            os.flush();

            for (int k = 0; k < Blockchain_Task.size(); k++) {
                os.println(Blockchain_Task.get(k).Pro_Hash);
                os.flush();
                os.println(Blockchain_Task.get(k).id);
                os.flush();
                os.println(Blockchain_Task.get(k).value);
                os.flush();
                os.println(Blockchain_Task.get(k).description);
                os.flush();
                os.println(Blockchain_Task.get(k).date);
                os.flush();
                os.println(Blockchain_Task.get(k).Hash);
                os.flush();
                os.println(Blockchain_Task.get(k).Proof_w);
                os.flush();
                os.println(Blockchain_Task.get(k).public_k_e.toString());
                os.flush();
                os.println(Blockchain_Task.get(k).public_k_n.toString());
                os.flush();
                os.println(Blockchain_Task.get(k).signature);
                os.flush();
            }

            //Threshold-BC
            os.println(Blockchain_Threshold.size());
            os.flush();

            for (int k = 0; k < Blockchain_Threshold.size(); k++) {
                os.println(Blockchain_Threshold.get(k).Pro_Hash);
                os.flush();
                os.println(Blockchain_Threshold.get(k).id_task);
                os.flush();
                os.println(Blockchain_Threshold.get(k).id_object);
                os.flush();
                os.println(Blockchain_Threshold.get(k).value);
                os.flush();
                os.println(Blockchain_Threshold.get(k).date);
                os.flush();
                os.println(Blockchain_Threshold.get(k).Hash);
                os.flush();
                os.println(Blockchain_Threshold.get(k).Proof_w);
                os.flush();
                os.println(Blockchain_Threshold.get(k).public_k_e.toString());
                os.flush();
                os.println(Blockchain_Threshold.get(k).public_k_n.toString());
                os.flush();
                os.println(Blockchain_Threshold.get(k).signature);
                os.flush();
            }

            //Smart_Contract-BC
            os.println(Blockchain_Smart_c.size());
            os.flush();

            for (int k = 0; k < Blockchain_Smart_c.size(); k++) {
                os.println(Blockchain_Smart_c.get(k).Pro_Hash);
                os.flush();
                os.println(Blockchain_Smart_c.get(k).id);
                os.flush();
                os.println(Blockchain_Smart_c.get(k).date);
                os.flush();
                os.println(Blockchain_Smart_c.get(k).Hash);
                os.flush();
                os.println(Blockchain_Smart_c.get(k).Proof_w);
                os.flush();
                os.println(Blockchain_Smart_c.get(k).public_k_e.toString());
                os.flush();
                os.println(Blockchain_Smart_c.get(k).public_k_n.toString());
                os.flush();
                os.println(Blockchain_Smart_c.get(k).signature);
                os.flush();
            }
        }

        // record its address and give it the dominant BC
        public void New_Block() throws IOException, NoSuchAlgorithmException {
            /*
            // fill the info of new subject
            Sub_id = is.readLine();
            Sub_position = is.readLine();
            Sub_value = is.readLine();
            Sub_date = is.readLine();

            // create new block
            // Add new subject in BC
            Blockchain_Subject.add(new Block("000", Sub_id, Sub_position, Sub_value, Sub_date, "Hash", "PW", BigInteger.ONE, BigInteger.TEN, "Signature"));
            //list_Subjects.add(Sub_id);

             */
            create_block();

            // send the New Block (Subject or Object or Task .....) to the other subjects:
            // contact all Subjects
            for (int i = 0; i < list_Subjects.size(); i++) {
                System.out.println(list_Subjects.get(i));
                InetAddress address = null;
                try {
                    address = InetAddress.getLocalHost();
                } catch (UnknownHostException ex) {
                    Logger.getLogger(Advisor.class.getName()).log(Level.SEVERE, null, ex);
                }
                Socket s1 = null;
                String line = null;
                BufferedReader br = null;
                BufferedReader is = null;
                PrintWriter os = null;

                //      begin connection part 
                try {
                    s1 = new Socket(address, Integer.parseInt(list_Subjects.get(i)));
                    br = new BufferedReader(new InputStreamReader(System.in));
                    is = new BufferedReader(new InputStreamReader(s1.getInputStream()));
                    os = new PrintWriter(s1.getOutputStream());
                } catch (IOException ef) {
                    ef.printStackTrace();
                    System.err.print("IO Exception");
                }

                ////////   End conection part /////////////////////////////
                if (type_request.compareTo("Sub_request") == 0) {

                    os.println("add_New_Subject");
                    os.flush();

                    os.println(Blockchain_Subject.get(Blockchain_Subject.size() - 1).Pro_Hash);
                    os.flush();
                    os.println(Blockchain_Subject.get(Blockchain_Subject.size() - 1).id);
                    os.flush();
                    os.println(Blockchain_Subject.get(Blockchain_Subject.size() - 1).position);
                    os.flush();
                    os.println(Blockchain_Subject.get(Blockchain_Subject.size() - 1).value);
                    os.flush();
                    os.println(Blockchain_Subject.get(Blockchain_Subject.size() - 1).date);
                    os.flush();
                    os.println(Blockchain_Subject.get(Blockchain_Subject.size() - 1).Hash);
                    os.flush();
                    os.println(Blockchain_Subject.get(Blockchain_Subject.size() - 1).Proof_w);
                    os.flush();
                    os.println(Blockchain_Subject.get(Blockchain_Subject.size() - 1).signature);
                    os.flush();
                    os.println(Blockchain_Subject.get(Blockchain_Subject.size() - 1).public_k_e.toString());
                    os.flush();
                    os.println(Blockchain_Subject.get(Blockchain_Subject.size() - 1).public_k_n.toString());
                    os.flush();

                    //}
                } else if (type_request.compareTo("Ob_request") == 0) {
                    os.println("add_New_Object");
                    os.flush();

                    os.println(Blockchain_Object.get(Blockchain_Object.size() - 1).Pro_Hash);
                    os.flush();
                    os.println(Blockchain_Object.get(Blockchain_Object.size() - 1).id);
                    os.flush();
                    os.println(Blockchain_Object.get(Blockchain_Object.size() - 1).id_s);
                    os.flush();
                    os.println(Blockchain_Object.get(Blockchain_Object.size() - 1).value);
                    os.flush();
                    os.println(Blockchain_Object.get(Blockchain_Object.size() - 1).date);
                    os.flush();
                    os.println(Blockchain_Object.get(Blockchain_Object.size() - 1).Hash);
                    os.flush();
                    os.println(Blockchain_Object.get(Blockchain_Object.size() - 1).Proof_w);
                    os.flush();
                    os.println(Blockchain_Object.get(Blockchain_Object.size() - 1).signature);
                    os.flush();
                    os.println(Blockchain_Object.get(Blockchain_Object.size() - 1).public_k_e.toString());
                    os.flush();
                    os.println(Blockchain_Object.get(Blockchain_Object.size() - 1).public_k_n.toString());
                    os.flush();

                } else if (type_request.compareTo("Ta_request") == 0) {
                    os.println("add_New_Task");
                    os.flush();

                    os.println(Blockchain_Task.get(Blockchain_Task.size() - 1).Pro_Hash);
                    os.flush();
                    os.println(Blockchain_Task.get(Blockchain_Task.size() - 1).id);
                    os.flush();
                    os.println(Blockchain_Task.get(Blockchain_Task.size() - 1).value);
                    os.flush();
                    os.println(Blockchain_Task.get(Blockchain_Task.size() - 1).description);
                    os.flush();
                    os.println(Blockchain_Task.get(Blockchain_Task.size() - 1).date);
                    os.flush();
                    os.println(Blockchain_Task.get(Blockchain_Task.size() - 1).Hash);
                    os.flush();
                    os.println(Blockchain_Task.get(Blockchain_Task.size() - 1).Proof_w);
                    os.flush();
                    os.println(Blockchain_Task.get(Blockchain_Task.size() - 1).signature);
                    os.flush();
                    os.println(Blockchain_Task.get(Blockchain_Task.size() - 1).public_k_e.toString());
                    os.flush();
                    os.println(Blockchain_Task.get(Blockchain_Task.size() - 1).public_k_n.toString());
                    os.flush();

                    String id_tas = Blockchain_Task.get(Blockchain_Task.size() - 1).id;
                    // fill the task in the combobox
                    DefaultComboBoxModel model = (DefaultComboBoxModel) id_task_th.getModel();
                    if (!list_Tas.contains(id_tas)) {
                        list_Tas.add(id_tas);
                        model.addElement(id_tas);
                    }

                } else if (type_request.compareTo("Thr_request") == 0) {
                    os.println("add_New_Threshold");
                    os.flush();

                    os.println(Blockchain_Threshold.get(Blockchain_Threshold.size() - 1).Pro_Hash);
                    os.flush();
                    os.println(Blockchain_Threshold.get(Blockchain_Threshold.size() - 1).id_task);
                    os.flush();
                    os.println(Blockchain_Threshold.get(Blockchain_Threshold.size() - 1).id_object);
                    os.flush();
                    os.println(Blockchain_Threshold.get(Blockchain_Threshold.size() - 1).value);
                    os.flush();
                    os.println(Blockchain_Threshold.get(Blockchain_Threshold.size() - 1).date);
                    os.flush();
                    os.println(Blockchain_Threshold.get(Blockchain_Threshold.size() - 1).Hash);
                    os.flush();
                    os.println(Blockchain_Threshold.get(Blockchain_Threshold.size() - 1).Proof_w);
                    os.flush();
                    os.println(Blockchain_Threshold.get(Blockchain_Threshold.size() - 1).signature);
                    os.flush();
                    os.println(Blockchain_Threshold.get(Blockchain_Threshold.size() - 1).public_k_e.toString());
                    os.flush();
                    os.println(Blockchain_Threshold.get(Blockchain_Threshold.size() - 1).public_k_n.toString());
                    os.flush();

                } else if (type_request.compareTo("SC_request") == 0) {
                    os.println("add_New_Smart_C");
                    os.flush();

                    os.println(Blockchain_Smart_c.get(Blockchain_Smart_c.size() - 1).Pro_Hash);
                    os.flush();
                    os.println(Blockchain_Smart_c.get(Blockchain_Smart_c.size() - 1).id);
                    os.flush();
                    os.println(Blockchain_Smart_c.get(Blockchain_Smart_c.size() - 1).date);
                    os.flush();
                    os.println(Blockchain_Smart_c.get(Blockchain_Smart_c.size() - 1).Hash);
                    os.flush();
                    os.println(Blockchain_Smart_c.get(Blockchain_Smart_c.size() - 1).Proof_w);
                    os.flush();
                    os.println(Blockchain_Smart_c.get(Blockchain_Smart_c.size() - 1).signature);
                    os.flush();
                    os.println(Blockchain_Smart_c.get(Blockchain_Smart_c.size() - 1).public_k_e.toString());
                    os.flush();
                    os.println(Blockchain_Smart_c.get(Blockchain_Smart_c.size() - 1).public_k_n.toString());
                    os.flush();

                }

            }
            show_BCs();
        }

        void create_block() throws IOException, NoSuchAlgorithmException {
            String DATA = null, Sub_Ob_id = null, Ob_value = null, Ob_date = null, ta_id = null, ta_th_id = null, ob_th_id = null,
                    ta_value = null, ta_date = null, ta_description = null, th_value = null, th_date = null,
                    sc_id = null, sc_date = null, Previous_H;
            String signature = "0000";

            if (type_request.compareTo("Sub_request") == 0) {
                //line = is.readLine();
                Sub_id = id_subject.getSelectedItem().toString();
                //line = is.readLine();
                Sub_position = posiotion_sub.getText();
                // line = is.readLine();
                Sub_value = value_sub.getText();
                // line = is.readLine();
                Sub_date = date_sub.getText();
                DATA = Sub_id + Sub_position + Sub_value + Sub_date;
                //list_Subjects.add(Sub_id);
            } else if (type_request.compareTo("Ob_request") == 0) {
                Ob_id = id_object.getSelectedItem().toString();
                Sub_Ob_id = id_subject_ob.getSelectedItem().toString();
                Ob_value = value_ob.getText();
                Ob_date = date_ob.getText();

                // get the ID subject from the Advisor input.
                DATA = Ob_id + Sub_Ob_id + Ob_value + Ob_date;

            } else if (type_request.compareTo("Ta_request") == 0) {
                ta_id = id_ta.getText();
                ta_value = value_ta.getText();
                ta_description = desc_ta.getText();
                ta_date = date_ta.getText();

                // get the ID subject from the Advisor input.
                DATA = ta_id + ta_value + ta_description + ta_date;

            } else if (type_request.compareTo("Thr_request") == 0) {
                ta_th_id = id_task_th.getSelectedItem().toString();
                ob_th_id = id_object_th.getSelectedItem().toString();
                th_value = value_th.getText();
                th_date = date_th.getText();

                // get the ID subject from the Advisor input.
                DATA = ta_th_id + ob_th_id + th_value + th_date;

            } else if (type_request.compareTo("SC_request") == 0) {
                sc_id = id_sc.getSelectedItem().toString();
                sc_date = date_sc.getText();

                // get the ID subject from the Advisor input.
                DATA = sc_id + sc_date;

            }
            Generate_Keys();
            // Get the Previous hash
            Previous_H = get_previous_Hash();

            // request the Miner about the hash and Proof od work of Block:
            Request_Proof_W(Previous_H + DATA + public_k_e.toString() + public_k_n.toString());

            // signature                
            BigInteger msg = new BigInteger(HASH_DATA.getBytes());
            byte[] encrypte = msg.modPow(private_k_d, public_k_n).toByteArray();
            signature = toHex(encrypte);

            // create the Block by the information:
            if (type_request.compareTo("Sub_request") == 0) {
                //genisis block
                if (Blockchain_Subject.size() == 0) {
                    Blockchain_Subject.add(new Block_Sub("0000", Sub_id, Sub_position, Sub_value, Sub_date, HASH_DATA, PROOF_WORK, public_k_e, public_k_n, signature));
                } else {
                    Blockchain_Subject.add(new Block_Sub(Blockchain_Subject.get(Blockchain_Subject.size() - 1).Hash, Sub_id, Sub_position, Sub_value, Sub_date, HASH_DATA, PROOF_WORK, public_k_e, public_k_n, signature));
                }
            } else if (type_request.compareTo("Ob_request") == 0) {
                //genisis block
                if (Blockchain_Object.size() == 0) {
                    Blockchain_Object.add(new Block_Ob("0000", Ob_id, Sub_Ob_id, Ob_value, Ob_date, HASH_DATA, PROOF_WORK, public_k_e, public_k_n, signature));

                } else {
                    Blockchain_Object.add(new Block_Ob(Blockchain_Object.get(Blockchain_Object.size() - 1).Hash, Ob_id, Sub_Ob_id, Ob_value, Ob_date, HASH_DATA, PROOF_WORK, public_k_e, public_k_n, signature));
                }
            } else if (type_request.compareTo("Ta_request") == 0) {
                //genisis block
                if (Blockchain_Task.size() == 0) {
                    Blockchain_Task.add(new Block_Task("0000", ta_id, ta_value, ta_description, ta_date, HASH_DATA, PROOF_WORK, public_k_e, public_k_n, signature));

                } else {
                    Blockchain_Task.add(new Block_Task(Blockchain_Task.get(Blockchain_Task.size() - 1).Hash, ta_id, ta_value, ta_description, ta_date, HASH_DATA, PROOF_WORK, public_k_e, public_k_n, signature));
                }
            } else if (type_request.compareTo("Thr_request") == 0) {
                //genisis block
                if (Blockchain_Threshold.size() == 0) {
                    Blockchain_Threshold.add(new Block_Threshold("0000", ta_th_id, ob_th_id, th_value, th_date, HASH_DATA, PROOF_WORK, public_k_e, public_k_n, signature));

                } else {
                    Blockchain_Threshold.add(new Block_Threshold(Blockchain_Threshold.get(Blockchain_Threshold.size() - 1).Hash, ta_th_id, ob_th_id, th_value, th_date, HASH_DATA, PROOF_WORK, public_k_e, public_k_n, signature));
                }
            } else if (type_request.compareTo("SC_request") == 0) {
                //genisis block
                if (Blockchain_Smart_c.size() == 0) {
                    Blockchain_Smart_c.add(new Block_Smart_Contract("0000", sc_id, sc_date, HASH_DATA, PROOF_WORK, public_k_e, public_k_n, signature));

                } else {
                    Blockchain_Smart_c.add(new Block_Smart_Contract(Blockchain_Smart_c.get(Blockchain_Smart_c.size() - 1).Hash, sc_id, sc_date, HASH_DATA, PROOF_WORK, public_k_e, public_k_n, signature));
                }
            }

        }

        String get_previous_Hash() {
            String P_hash = "0000";

            if (type_request.compareTo("Sub_request") == 0) {
                if (Blockchain_Subject.size() > 0) {
                    P_hash = Blockchain_Subject.get(Blockchain_Subject.size() - 1).Hash;
                }
            } else if (type_request.compareTo("Ob_request") == 0) {
                if (Blockchain_Object.size() > 0) {
                    P_hash = Blockchain_Object.get(Blockchain_Object.size() - 1).Hash;
                }
            } else if (type_request.compareTo("Ta_request") == 0) {
                if (Blockchain_Task.size() > 0) {
                    P_hash = Blockchain_Task.get(Blockchain_Task.size() - 1).Hash;
                }
            } else if (type_request.compareTo("Thr_request") == 0) {
                if (Blockchain_Threshold.size() > 0) {
                    P_hash = Blockchain_Threshold.get(Blockchain_Threshold.size() - 1).Hash;
                }
            } else if (type_request.compareTo("SC_request") == 0) {
                if (Blockchain_Smart_c.size() > 0) {
                    P_hash = Blockchain_Smart_c.get(Blockchain_Smart_c.size() - 1).Hash;
                }
            }

            return P_hash;
        }

        void show_BCs() {

            show.append("<<<<< Start Blockchain_Subject >>>>>>>\n");
            for (int i = 0; i < Blockchain_Subject.size(); i++) {
                show.append("--------  BLOCK N= " + (i + 1) + "--------\n");
                show.append("Provious Hash: " + Blockchain_Subject.get(i).Pro_Hash + "\n");
                show.append("ID: " + Blockchain_Subject.get(i).id + "\n");
                show.append("Position: " + Blockchain_Subject.get(i).position + "\n");
                show.append("Value: " + Blockchain_Subject.get(i).value + "\n");
                show.append("Date: " + Blockchain_Subject.get(i).date + "\n");
                show.append("Hash:  " + Blockchain_Subject.get(i).Hash + "\n");
                show.append("Proof of Work: " + Blockchain_Subject.get(i).Proof_w + "\n");
                show.append("The Public key (e,n):\n");
                show.append("e: " + Blockchain_Subject.get(i).public_k_e + "\n");
                show.append("n: " + Blockchain_Subject.get(i).public_k_n + "\n");
                show.append("Digital Signature: " + Blockchain_Subject.get(i).signature + "\n");
            }
            show.append("<<<<< End Blockchain_Subject >>>>>>>\n");

            show.append("<<<<< Start Blockchain_Object >>>>>>>\n");
            for (int i = 0; i < Blockchain_Object.size(); i++) {
                show.append("--------  BLOCK N= " + (i + 1) + "--------\n");
                show.append("Provious Hash: " + Blockchain_Object.get(i).Pro_Hash + "\n");
                show.append("ID Object: " + Blockchain_Object.get(i).id + "\n");
                show.append("ID Subject: " + Blockchain_Object.get(i).id_s + "\n");
                show.append("Value: " + Blockchain_Object.get(i).value + "\n");
                show.append("Date: " + Blockchain_Object.get(i).date + "\n");
                show.append("Hash:  " + Blockchain_Object.get(i).Hash + "\n");
                show.append("Proof of Work: " + Blockchain_Object.get(i).Proof_w + "\n");
                show.append("The Public key (e,n):\n");
                show.append("e: " + Blockchain_Object.get(i).public_k_e + "\n");
                show.append("n: " + Blockchain_Object.get(i).public_k_n + "\n");
                show.append("Digital Signature: " + Blockchain_Object.get(i).signature + "\n");
            }
            show.append("<<<<< End Blockchain_Object >>>>>>>\n");

            show.append("<<<<< Start Blockchain_Tasksk >>>>>>>\n");
            for (int i = 0; i < Blockchain_Task.size(); i++) {
                show.append("--------  BLOCK N= " + (i + 1) + "--------\n");
                show.append("Provious Hash: " + Blockchain_Task.get(i).Pro_Hash + "\n");
                show.append("ID: " + Blockchain_Task.get(i).id + "\n");
                show.append("Value: " + Blockchain_Task.get(i).value + "\n");
                show.append("Description: " + Blockchain_Task.get(i).description + "\n");
                show.append("Date: " + Blockchain_Task.get(i).date + "\n");
                show.append("Hash:  " + Blockchain_Task.get(i).Hash + "\n");
                show.append("Proof of Work: " + Blockchain_Task.get(i).Proof_w + "\n");
                show.append("The Public key (e,n):\n");
                show.append("e: " + Blockchain_Task.get(i).public_k_e + "\n");
                show.append("n: " + Blockchain_Task.get(i).public_k_n + "\n");
                show.append("Digital Signature: " + Blockchain_Task.get(i).signature + "\n");
            }
            show.append("<<<<< End Blockchain_Tasksk >>>>>>>\n");

            show.append("<<<<< Start Blockchain_Thresholdeshold >>>>>>>\n");
            for (int i = 0; i < Blockchain_Threshold.size(); i++) {
                show.append("--------  BLOCK N= " + (i + 1) + "--------\n");
                show.append("Provious Hash: " + Blockchain_Threshold.get(i).Pro_Hash + "\n");
                show.append("ID Task: " + Blockchain_Threshold.get(i).id_task + "\n");
                show.append("ID Object: " + Blockchain_Threshold.get(i).id_object + "\n");
                show.append("Value: " + Blockchain_Threshold.get(i).value + "\n");
                show.append("Date: " + Blockchain_Threshold.get(i).date + "\n");
                show.append("Hash:  " + Blockchain_Threshold.get(i).Hash + "\n");
                show.append("Proof of Work: " + Blockchain_Threshold.get(i).Proof_w + "\n");
                show.append("The Public key (e,n):\n");
                show.append("e: " + Blockchain_Threshold.get(i).public_k_e + "\n");
                show.append("n: " + Blockchain_Threshold.get(i).public_k_n + "\n");
                show.append("Digital Signature: " + Blockchain_Threshold.get(i).signature + "\n");
            }
            show.append("<<<<< End Blockchain_Thresholdeshold >>>>>>>\n");

            show.append("<<<<< Start Blockchain_Smart_Contract >>>>>>>\n");
            for (int i = 0; i < Blockchain_Smart_c.size(); i++) {
                show.append("--------  BLOCK N= " + (i + 1) + "--------\n");
                show.append("Provious Hash: " + Blockchain_Smart_c.get(i).Pro_Hash + "\n");
                show.append("ID: " + Blockchain_Smart_c.get(i).id + "\n");
                show.append("Date: " + Blockchain_Smart_c.get(i).date + "\n");
                show.append("Hash:  " + Blockchain_Smart_c.get(i).Hash + "\n");
                show.append("Proof of Work: " + Blockchain_Smart_c.get(i).Proof_w + "\n");
                show.append("The Public key (e,n):\n");
                show.append("e: " + Blockchain_Smart_c.get(i).public_k_e + "\n");
                show.append("n: " + Blockchain_Smart_c.get(i).public_k_n + "\n");
                show.append("Digital Signature: " + Blockchain_Smart_c.get(i).signature + "\n");
            }
            show.append("<<<<< End Blockchain_Smart_Contract >>>>>>>\n");

        }

    }

    void Generate_Keys() throws NoSuchAlgorithmException {

        // communicate the Miner so, the in this case the manager is considered as client and the Miner is as server.
        ////////  Start conection part /////////////////////////////
        InetAddress address = null;
        try {
            address = InetAddress.getLocalHost();
        } catch (UnknownHostException ex) {
            Logger.getLogger(Advisor.class.getName()).log(Level.SEVERE, null, ex);
        }
        Socket s1 = null;
        String line = null;
        BufferedReader br = null;
        BufferedReader is = null;
        PrintWriter os = null;

        try {
            s1 = new Socket(address, MinerPort);
            br = new BufferedReader(new InputStreamReader(System.in));
            is = new BufferedReader(new InputStreamReader(s1.getInputStream()));
            os = new PrintWriter(s1.getOutputStream());
        } catch (IOException ef) {
            ef.printStackTrace();
            System.err.print("IO Exception");
        }

        ////////   End conection part /////////////////////////////
        try {

            os.println("Key?");
            os.flush();
            public_k_e = new BigInteger(is.readLine());
            private_k_d = new BigInteger(is.readLine());
            public_k_n = new BigInteger(is.readLine());
            if (type_request.compareTo("Sub_request") == 0) {
                list_sub.add(new Subject_inf(Sub_id, public_k_e, private_k_d, public_k_n));
            } //else if (type_request.compareTo("Ob_request") == 0) {
            // list_obj.add(new Object_inf(Ob_id, public_k_e, private_k_d, public_k_n));
            //}
        } catch (IOException ef) {
            ef.printStackTrace();
            show.append("Socket read Error\n");
        } finally {

            try {
                is.close();
                os.close();
                br.close();
                s1.close();
            } catch (IOException ex) {
                //show.append("Connection Closed");  
            }

        }

    }

    void Request_Proof_W(String DATA) {

        ////////  Start conection part /////////////////////////////
        InetAddress address = null;
        try {
            address = InetAddress.getLocalHost();
        } catch (UnknownHostException ex) {
            Logger.getLogger(Advisor.class.getName()).log(Level.SEVERE, null, ex);
        }
        Socket s1 = null;
        String line = null;
        BufferedReader br = null;
        BufferedReader is = null;
        PrintWriter os = null;

        try {
            s1 = new Socket(address, MinerPort); // The port of the Miner
            br = new BufferedReader(new InputStreamReader(System.in));
            is = new BufferedReader(new InputStreamReader(s1.getInputStream()));
            os = new PrintWriter(s1.getOutputStream());
        } catch (IOException ef) {
            ef.printStackTrace();
            System.err.print("IO Exception");
        }

        ////////   End conection part /////////////////////////////
        try {

            os.println("proof_W?");
            os.flush();
            os.println(DATA);
            os.flush();
            // receive the hash and the proof of work
            HASH_DATA = is.readLine();
            PROOF_WORK = is.readLine();

        } catch (IOException ef) {
            ef.printStackTrace();
            show.append("Socket read Error\n");
        } finally {

            try {
                is.close();
                os.close();
                br.close();
                s1.close();
            } catch (IOException ex) {
                //show.append("Connection Closed");  
            }

        }

    }

    public String toHex(byte[] bytes) {
        BigInteger bi = new BigInteger(1, bytes);
        return String.format("%0" + (bytes.length << 1) + "X", bi);
    }

    /*
        public boolean get_dominant_BC(List<Integer> confidance) throws IOException {
            System.out.println("----- In the get_dominant_BC ------");
            Blockchain_Subject = new ArrayList<Block>();
            InetAddress address = null;
            try {
                address = InetAddress.getLocalHost();
            } catch (UnknownHostException ex) {
                Logger.getLogger(Advisor.class.getName()).log(Level.SEVERE, null, ex);
            }
            Socket s1 = null;
            String line = null;
            BufferedReader br = null;
            BufferedReader is = null;
            PrintWriter os = null;
            // contact all subjects
            for (int i = 0; i < confidance.size(); i++) {
                // eleminate this subject.
                if (confidance.get(i) != Integer.parseInt(Sub_id)) {

                    //      begin connection part 
                    try {
                        s1 = new Socket(address, confidance.get(i));
                        br = new BufferedReader(new InputStreamReader(System.in));
                        is = new BufferedReader(new InputStreamReader(s1.getInputStream()));
                        os = new PrintWriter(s1.getOutputStream());
                    } catch (IOException ef) {
                        ef.printStackTrace();
                        System.err.print("IO Exception");
                    }
                    ////////   End conection part /////////////////////////////

                    // get the BC.
                    os.println("give_BC");
                    os.flush();

                    // get the size of the BC
                    int sizeBC = Integer.parseInt(is.readLine());

                    for (int k = 0; k < sizeBC; k++) {

                        Blockchain_Subject.add(new Block(is.readLine(), is.readLine(), is.readLine(), is.readLine(), is.readLine(), is.readLine(), is.readLine(),
                                new BigInteger(is.readLine()), new BigInteger(is.readLine()), is.readLine()));
                    }

                    int count_identic = 0;
                    boolean contradiction = false;

                    // contact the other subjects
                    for (int j = 0; j < confidance.size(); j++) {
                        // eleminate this subject.
                        if (confidance.get(i) != Integer.parseInt(Sub_id)) {
                            //&& list_Subjects.get(j).compareTo(list_Subjects.get(i)) != 0) {
                            //      begin connection part 
                            try {
                                s1 = new Socket(address, confidance.get(i));
                                br = new BufferedReader(new InputStreamReader(System.in));
                                is = new BufferedReader(new InputStreamReader(s1.getInputStream()));
                                os = new PrintWriter(s1.getOutputStream());
                            } catch (IOException ef) {
                                ef.printStackTrace();
                                System.err.print("IO Exception");
                            }
                            ////////   End conection part /////////////////////////////

                            // get the BC.
                            os.println("give_BC");
                            os.flush();

                            // get the size of the BC
                            sizeBC = Integer.parseInt(is.readLine());

                            for (int k = 0; k < sizeBC; k++) {
                                if (Blockchain_Subject.get(k).Pro_Hash.compareTo(is.readLine()) != 0
                                        || Blockchain_Subject.get(k).id.compareTo(is.readLine()) != 0
                                        || Blockchain_Subject.get(k).position.compareTo(is.readLine()) != 0
                                        || Blockchain_Subject.get(k).value.compareTo(is.readLine()) != 0
                                        || Blockchain_Subject.get(k).date.compareTo(is.readLine()) != 0
                                        || Blockchain_Subject.get(k).Hash.compareTo(is.readLine()) != 0
                                        || Blockchain_Subject.get(k).Proof_w.compareTo(is.readLine()) != 0
                                        || Blockchain_Subject.get(k).public_k_e.toString().compareTo(is.readLine()) != 0
                                        || Blockchain_Subject.get(k).public_k_n.toString().compareTo(is.readLine()) != 0
                                        || Blockchain_Subject.get(k).signature.compareTo(is.readLine()) != 0) {
                                    contradiction = true;
                                }
                                break;
                            }
                            if (contradiction == false) {
                                count_identic++;

                            }
                            if (count_identic * 100 / confidance.size() > 50) {

                                return true;
                            }
                        }
                    }

                }
            }

            return false;

        }

        boolean select_dominant_BC() throws UnknownHostException, IOException {
            System.out.println("----- In the select_dominant_BC ------");
            int c, A_max = 0, B_max, C_max;
            // Defin the ranks and their ratios
            int R_A = 80, R_B = 60, R_C = 10;
            boolean valid;
            List<Integer> cc_Subjects = new ArrayList<Integer>();
            List<Integer> Rank_A = new ArrayList<Integer>();
            List<Integer> Rank_B = new ArrayList<Integer>();
            List<Integer> Rank_C = new ArrayList<Integer>();
            List<Integer> confidance = new ArrayList<Integer>();
            List<String> list_other_subjects = new ArrayList<String>();

            InetAddress address = InetAddress.getLocalHost();
            Socket s1 = null;
            String line = null;
            BufferedReader br = null;
            BufferedReader is = null;
            PrintWriter os = null;

            System.out.println();
            for (int i = 0; i < list_Subjects.size(); i++) {
                System.out.print(" |||| " + list_Subjects.get(i));
            }
            System.out.println();

            for (int i = 0; i < list_Subjects.size(); i++) {
                list_other_subjects.add(list_Subjects.get(i));
            }

            System.out.println();
            for (int i = 0; i < list_Subjects.size(); i++) {
                System.out.print(" ||||| " + list_Subjects.get(i));
            }
            System.out.println();
            for (int i = 0; i < list_other_subjects.size(); i++) {
                if (list_other_subjects.get(i).compareTo(Sub_id) == 0) {
                    System.out.println("The subject " + list_other_subjects.get(i) + " is removed");
                    list_other_subjects.remove(i);
                    break;
                }

            }

            System.out.println("List other subject:");
            for (int i = 0; i < list_other_subjects.size(); i++) {
                System.out.print(" | " + list_other_subjects.get(i));
            }
            System.out.println();

            System.out.println("List subjects:");
            for (int i = 0; i < list_Subjects.size(); i++) {
                System.out.print(" | " + list_Subjects.get(i));
            }
            System.out.println();

            System.out.println("The cc of the subjects:");
            for (int i = 0; i < list_other_subjects.size(); i++) {
                ////////   Begin conection part /////////////////////////////
                s1 = new Socket(address, Integer.parseInt(list_other_subjects.get(i)));
                br = new BufferedReader(new InputStreamReader(System.in));
                is = new BufferedReader(new InputStreamReader(s1.getInputStream()));
                os = new PrintWriter(s1.getOutputStream());
                ////////   End conection part /////////////////////////////
                os.println("get_cc");
                os.flush();
                cc_Subjects.add(Integer.parseInt(is.readLine()));
                System.out.println("Subject " + list_other_subjects.get(i) + " :" + cc_Subjects.get(i));

                // get the max cc between all the subjects
                if (cc_Subjects.get(i) > A_max) {
                    A_max = cc_Subjects.get(i);
                }

            }

            B_max = (60 * A_max) / 100;
            C_max = (30 * A_max) / 100;
            System.out.println("A_max: " + A_max + " - B_max: " + B_max + " - C_max: " + C_max);

            System.out.println("------- classify the ranks ----------");
            // Classify the subjects
            for (int i = 0; i < list_other_subjects.size(); i++) {
                if (cc_Subjects.get(i) <= A_max && cc_Subjects.get(i) > B_max) {
                    System.out.println("Rank_A: " + list_other_subjects.get(i));
                    Rank_A.add(Integer.parseInt(list_other_subjects.get(i)));
                } else if (cc_Subjects.get(i) <= B_max && cc_Subjects.get(i) > C_max) {
                    System.out.println("Rank_B: " + Integer.parseInt(list_other_subjects.get(i)));
                    Rank_B.add(Integer.parseInt(list_other_subjects.get(i)));
                } else {
                    System.out.println("Rank_C: " + list_other_subjects.get(i));
                    Rank_C.add(Integer.parseInt(list_other_subjects.get(i)));
                }
            }

            // Calculate the number of the subject of each rank.
            int NA = (R_A * Rank_A.size()) / 100;
            int NB = (R_B * Rank_B.size()) / 100;
            int NC = (R_C * Rank_C.size()) / 100;

            if (NA == 0 && NB == 0 && NC == 0 && Rank_A.size() > 0) {
                NA = 1;
            }
            System.out.println("NA: " + NA + " - NB: " + NB + " - NC: " + NC);

            //fill the confidance subjects
            for (int i = 0; i < NA; i++) {
                do {
                    //int randomNum = ThreadLocalRandom.current().nextInt(min, max + 1);
                    int randomNum = ThreadLocalRandom.current().nextInt(0, Rank_A.size());
                    c = Rank_A.get(randomNum);
                } while (confidance.contains(c));
                confidance.add(c);
            }
            for (int i = 0; i < NB; i++) {
                do {
                    int randomNum = ThreadLocalRandom.current().nextInt(0, Rank_B.size());
                    c = Rank_B.get(randomNum);
                } while (confidance.contains(c));
                confidance.add(c);
            }
            for (int i = 0; i < NC; i++) {
                do {
                    int randomNum = ThreadLocalRandom.current().nextInt(0, Rank_C.size());
                    c = Rank_C.get(randomNum);
                } while (confidance.contains(c));
                confidance.add(c);
            }
            return get_dominant_BC(confidance);

        }
     */
    public class Task extends Thread {

        public void run() {

        }
    }

// BC of Subject
    public class Block_Sub {

        String Pro_Hash;
        String id;
        String position;
        String value;
        String date;
        String Hash;
        String Proof_w;
        BigInteger public_k_e;
        BigInteger public_k_n;
        String signature;

        Block_Sub(String Pro_Hash, String id, String position, String value, String date, String Hash, String Proof_w, BigInteger public_k_e, BigInteger public_k_n, String signature) {
            this.Pro_Hash = Pro_Hash;
            this.id = id;
            this.position = position;
            this.value = value;
            this.date = date;
            this.Hash = Hash;
            this.Proof_w = Proof_w;
            this.public_k_e = public_k_e;
            this.public_k_n = public_k_n;
            this.signature = signature;
        }

    }

    public class Block_Ob {

        String Pro_Hash;
        String id;
        String id_s;
        String value;
        String date;
        String Hash;
        String Proof_w;
        BigInteger public_k_e;
        BigInteger public_k_n;
        String signature;

        Block_Ob(String Pro_Hash, String id, String id_s, String value, String date, String Hash, String Proof_w, BigInteger public_k_e, BigInteger public_k_n, String signature) {
            this.Pro_Hash = Pro_Hash;
            this.id = id;
            this.id_s = id_s;
            this.value = value;
            this.date = date;
            this.Hash = Hash;
            this.Proof_w = Proof_w;
            this.public_k_e = public_k_e;
            this.public_k_n = public_k_n;
            this.signature = signature;
        }

    }

    public class Block_Task {

        String Pro_Hash;
        String id;
        String value;
        String description;
        String date;
        String Hash;
        String Proof_w;
        BigInteger public_k_e;
        BigInteger public_k_n;
        String signature;

        Block_Task(String Pro_Hash, String id, String value, String description, String date, String Hash, String Proof_w, BigInteger public_k_e, BigInteger public_k_n, String signature) {
            this.Pro_Hash = Pro_Hash;
            this.id = id;
            this.value = value;
            this.description = description;
            this.date = date;
            this.Hash = Hash;
            this.Proof_w = Proof_w;
            this.public_k_e = public_k_e;
            this.public_k_n = public_k_n;
            this.signature = signature;
        }

    }

    public class Block_Threshold {

        String Pro_Hash;
        String id_task;
        String id_object;
        String value;
        String date;
        String Hash;
        String Proof_w;
        BigInteger public_k_e;
        BigInteger public_k_n;
        String signature;

        Block_Threshold(String Pro_Hash, String id_task, String id_object, String value, String date, String Hash, String Proof_w, BigInteger public_k_e, BigInteger public_k_n, String signature) {
            this.Pro_Hash = Pro_Hash;
            this.id_task = id_task;
            this.id_object = id_object;
            this.value = value;
            this.date = date;
            this.Hash = Hash;
            this.Proof_w = Proof_w;
            this.public_k_e = public_k_e;
            this.public_k_n = public_k_n;
            this.signature = signature;
        }

    }

    public class Block_Smart_Contract {

        String Pro_Hash;
        String id;
        String date;
        String Hash;
        String Proof_w;
        BigInteger public_k_e;
        BigInteger public_k_n;
        String signature;

        Block_Smart_Contract(String Pro_Hash, String id, String date, String Hash, String Proof_w, BigInteger public_k_e, BigInteger public_k_n, String signature) {
            this.Pro_Hash = Pro_Hash;
            this.id = id;
            this.date = date;
            this.Hash = Hash;
            this.Proof_w = Proof_w;
            this.public_k_e = public_k_e;
            this.public_k_n = public_k_n;
            this.signature = signature;
        }

    }

    public class Subject_inf {

        String id = null;
        BigInteger e;
        BigInteger d;
        BigInteger n;

        public Subject_inf(String id, BigInteger e, BigInteger d, BigInteger n) {
            this.id = id;
            this.e = e;
            this.d = d;
            this.n = n;
        }

    }

    public class Object_inf {

        String id;
        String value;
        String date;

        public Object_inf(String id, String value, String date) {
            this.id = id;
            this.value = value;
            this.date = date;

        }
    }

}
